//Currently working on slideshow
var img1= "url(/wall.jpg)";
$("body").css("background-image",img1);




