$(".reply").on("click",function(){
    $(this).siblings("#replybox").toggleClass("replybox");
});

